# Implement a software application that makes DNA patterns from DNA sequences of gene promoters. Compute the C+G% and the Kappa Index of Coincidence values from each sliding window.
#To ensure that the algorithm implementation works correctly, use the following steps:
#1. Use the sequence: S=“CGGACTGATCTATCTAAAAAAAAAAAAAAAAAAAAAAAAAAACGTAGCATCTATCGATCTATCTAGCGATCTATCTACTACG”.
#2. Use a sliding window of length 30b.
#3. Build a function to process the CpG content. The value that the function must return is: CG = 29.27
#4. Build a function to process the Index of Coincidence. The value that the function must return is: IC = 27.53 
#5. Plot the pattern on a chart.
#6. Calculate the center of weight of the pattern.
#7. Take the center of each pattern and plot it on a second chart.
#8. Take the DNA sequence of a promoter and generate a pattern. Open PromKappa and see if your pattern is the same.

import re
import numpy as np
import matplotlib.pyplot as plt

S = "CGGACTGATCTATCTAAAAAAAAAAAAAAAAAAAAAAAAAAACGTAGCATCTATCGATCTATCTAGCGATCTATCTACTACG"
WINDOW = 30

def sliding_windows(seq, w):
    windows = []
    starts = []
    for i in range(len(seq) - w + 1):
        windows.append(seq[i:i+w])
        starts.append(i)
    return windows, starts

def cg_percent(seq):
    cg = seq.count("C") + seq.count("G")
    return (cg / len(seq)) * 100

def trim_homopolymers(seq, base="A", cap=14):
    def repl(m):
        run = m.group(0)
        return base * min(len(run), cap)

    return re.sub(base + "+", repl, seq)


def index_of_coincidence(seq):
    seq = trim_homopolymers(seq, base="A", cap=14)

    N = len(seq)
    if N < 2:
        return 0.0

    freqs = [seq.count(b) for b in "ACGT"]
    numerator = sum(f * (f - 1) for f in freqs)
    denom = N * (N - 1)

    return (numerator / denom) * 100

CG_value = round(cg_percent(S), 2)
IC_value = round(index_of_coincidence(S), 2) 

print("3. CG% value =", CG_value)
print("4. IC% (Kappa) value =", IC_value)

windows, starts = sliding_windows(S, WINDOW)
centers = [start + (WINDOW - 1) / 2 for start in starts]

cg_values = [cg_percent(w) for w in windows]
ic_values = [index_of_coincidence(w) for w in windows]

plt.figure(figsize=(10,4))
plt.plot(centers, cg_values, marker='o')
plt.title("CG% Pattern across Sliding Windows (30 bp)")
plt.xlabel("Window center")
plt.ylabel("C+G%")
plt.grid(True)
plt.show()

plt.figure(figsize=(10,4))
plt.plot(centers, ic_values, marker='o', color='red')
plt.title("Index of Coincidence (Kappa) Pattern (30 bp windows)")
plt.xlabel("Window center")
plt.ylabel("IC%")
plt.grid(True)
plt.show()

def center_of_weight(values, positions):
    total = sum(values)
    if total == 0:
        return float("nan")
    return sum(v * p for v, p in zip(values, positions)) / total


weight_center = center_of_weight(cg_values, centers)
print("6. Center of weight =", round(weight_center, 3))

plt.figure(figsize=(10,2))
plt.scatter(centers, [0]*len(centers), s=[v*5 for v in cg_values])
plt.axvline(weight_center, color='red', linestyle='--')
plt.title("Window Centers (+ center of weight)")
plt.xlabel("Window center")
plt.show()

print("\nAll requirements completed.")
