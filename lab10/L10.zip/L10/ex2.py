import os
import numpy as np
import matplotlib.pyplot as plt

FASTA_FILE = "C:/Users/msuru/Desktop/BIOINF/lab10/Promotori lista completa.fasta"
OUTPUT_FOLDER = "ODS"
WINDOW = 30
MAX_PROMOTERS = 10  

def fast_kappa_ic(win):
    arr = np.frombuffer(win.encode(), dtype='S1')
    n = len(arr)
    total = 0.0

    for shift in range(1, n):
        matches = np.sum(arr[:-shift] == arr[shift:])
        total += (matches / (n - shift)) * 100

    return total / (n - 1)

def cg_percent(win):
    return 100 * sum(b in ("C", "G") for b in win) / len(win)

def read_fasta_multi(path):
    seqs = {}
    name = None
    cur = []

    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if line.startswith(">"):
                if name:
                    seqs[name] = "".join(cur).upper()
                name = line[1:].strip()
                cur = []
            else:
                cur.append(line)
        if name:
            seqs[name] = "".join(cur).upper()

    return seqs

if not os.path.exists(OUTPUT_FOLDER):
    os.makedirs(OUTPUT_FOLDER)

promoters = read_fasta_multi(FASTA_FILE)
selected_proms = list(promoters.items())[:MAX_PROMOTERS] 

centers = []

for name, seq in selected_proms:
    print(f"Processing: {name}")

    cg_vals = []
    ic_vals = []

    for start in range(0, len(seq) - WINDOW + 1):
        w = seq[start:start + WINDOW]
        cg_vals.append(cg_percent(w))
        ic_vals.append(fast_kappa_ic(w))

    cx = sum(cg_vals) / len(cg_vals)
    cy = sum(ic_vals) / len(ic_vals)
    centers.append((name, cx, cy))

    ods_path = os.path.join(OUTPUT_FOLDER, f"{name}_ODS.txt")
    with open(ods_path, "w") as f:
        f.write("CG%\tIC\n")
        for x, y in zip(cg_vals, ic_vals):
            f.write(f"{x:.3f}\t{y:.3f}\n")

    plt.scatter(cg_vals, ic_vals, s=8)
    plt.title(f"ODS — {name}")
    plt.xlabel("C+G %")
    plt.ylabel("Kappa IC")
    plt.tight_layout()
    plt.savefig(os.path.join(OUTPUT_FOLDER, f"{name}_plot.png"))
    plt.close()

plt.figure()

for name, cx, cy in centers:
    plt.scatter(cx, cy)
    plt.text(cx + 0.2, cy + 0.2, name, fontsize=7)

plt.title("Centers of Weight — 10 Promoters")
plt.xlabel("C+G % (center)")
plt.ylabel("Kappa IC (center)")
plt.grid(True)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_FOLDER, "centers_plot.png"))
plt.show()

print("\n✓ DONE! All ODS saved in the folder:", OUTPUT_FOLDER)
