import os
import matplotlib.pyplot as plt

FOLDER = "C:/Users/msuru/Desktop/BIOINF/lab10/influenza_fastas" 
WINDOW = 30   


def read_fasta(path):
    seq = ""
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line.startswith(">"):
                continue
            seq += line
    return seq.upper()

def cg_percent(win):
    return 100 * sum(1 for b in win if b in ("C", "G")) / len(win)

def kappa_ic(win):
    n = len(win)
    total = 0
    for shift in range(1, n):
        matches = 0
        L = n - shift
        for i in range(L):
            if win[i] == win[i + shift]:
                matches += 1
        total += (matches / L) * 100
    return total / (n - 1)

def compute_stain(seq, window):
    CG = []
    IC = []
    for start in range(0, len(seq) - window + 1):
        w = seq[start:start + window]
        CG.append(cg_percent(w))
        IC.append(kappa_ic(w))
    return CG, IC

centers = []

for filename in os.listdir(FOLDER):
    if not filename.endswith(".fasta"):
        continue

    path = os.path.join(FOLDER, filename)
    seq = read_fasta(path)

    print(f"Processing {filename} (length {len(seq)} bp)")

    cg_vals, ic_vals = compute_stain(seq, WINDOW)
    cx = sum(cg_vals) / len(cg_vals)
    cy = sum(ic_vals) / len(ic_vals)
    centers.append((filename, cx, cy))

    plt.scatter(cg_vals, ic_vals, s=5)
    plt.title(f"Digital Stain — {filename}")
    plt.xlabel("C+G %")
    plt.ylabel("Kappa IC")
    plt.show()

plt.figure()

for name, cx, cy in centers:
    plt.scatter(cx, cy)
    plt.text(cx + 0.3, cy + 0.3, name, fontsize=8)

plt.title("Centers of Digital Stains (10 Influenza Genomes)")
plt.xlabel("C+G % (center)")
plt.ylabel("Kappa IC (center)")
plt.grid(True)
plt.show()
